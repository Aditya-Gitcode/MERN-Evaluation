# MERN Evaluation Submission – ProductManagerApp

Add, view, edit and delete products (with a thumbnail image) + search.

## Run

You need Node.js and MongoDB running on your computer.

**Backend** (terminal 1)
```
cd productmanager_backend
npm install
npm run dev
```

**Frontend** (terminal 2)
```
cd productmanager_frontend
npm install
npm run dev
```
Open the link shown in the terminal (usually http://localhost:5173).

## Folder guide
- `productmanager_backend/models` – product fields
- `productmanager_backend/controllers` – add / show / update / delete code
- `productmanager_backend/routes` – URLs
- `productmanager_backend/middleware/upload.js` – saves images into `uploads/`
- `productmanager_frontend/src/components` – Navbar, Home (list + search + delete), AddProduct, EditProduct
