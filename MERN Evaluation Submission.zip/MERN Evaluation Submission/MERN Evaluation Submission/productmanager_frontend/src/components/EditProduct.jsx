import axios from 'axios'
import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

const EditProduct = () => {

    const [product, setProduct] = useState({ productName: '', brand: '', category: '', price: '', stock: '', description: '', thumbnail: '' })
    const [newThumbnail, setNewThumbnail] = useState(null)
    const { id } = useParams()
    const navigate = useNavigate()

    useEffect(() => {
        axios.get(`http://localhost:4000/product/product/${id}`)
            .then((res) => setProduct(res.data))
            .catch((err) => console.log(err))
    }, [])

    const handleSubmit = (e) => {
        e.preventDefault()

        const formData = new FormData()
        formData.append('productName', product.productName)
        formData.append('brand', product.brand)
        formData.append('category', product.category)
        formData.append('price', product.price)
        formData.append('stock', product.stock)
        formData.append('description', product.description)

        if (newThumbnail) {
            formData.append('thumbnail', newThumbnail)
        }

        axios.put(`http://localhost:4000/product/${id}`, formData)
            .then(() => navigate('/'))
            .catch((err) => console.log(err))
    }

    return (
        <>
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-md-8">
                        <div className="card">
                            <div className="card-body">
                                <h4 className="card-title mb-3">Edit Product</h4>
                                <form onSubmit={handleSubmit}>
                                    <div className="form-floating mb-3">
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="productName"
                                            placeholder=""
                                            required
                                            value={product.productName}
                                            onChange={(e) => setProduct({ ...product, productName: e.target.value })}
                                        />
                                        <label htmlFor="productName">Product Name</label>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="brand"
                                            placeholder=""
                                            required
                                            value={product.brand}
                                            onChange={(e) => setProduct({ ...product, brand: e.target.value })}
                                        />
                                        <label htmlFor="brand">Brand</label>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="category"
                                            placeholder=""
                                            required
                                            value={product.category}
                                            onChange={(e) => setProduct({ ...product, category: e.target.value })}
                                        />
                                        <label htmlFor="category">Category</label>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-6">
                                            <div className="form-floating mb-3">
                                                <input
                                                    type="number"
                                                    className="form-control"
                                                    id="price"
                                                    placeholder=""
                                                    min="0"
                                                    required
                                                    value={product.price}
                                                    onChange={(e) => setProduct({ ...product, price: e.target.value })}
                                                />
                                                <label htmlFor="price">Price</label>
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-floating mb-3">
                                                <input
                                                    type="number"
                                                    className="form-control"
                                                    id="stock"
                                                    placeholder=""
                                                    min="0"
                                                    required
                                                    value={product.stock}
                                                    onChange={(e) => setProduct({ ...product, stock: e.target.value })}
                                                />
                                                <label htmlFor="stock">Stock</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <textarea
                                            className="form-control"
                                            id="description"
                                            placeholder=""
                                            style={{ height: '100px' }}
                                            value={product.description}
                                            onChange={(e) => setProduct({ ...product, description: e.target.value })}
                                        ></textarea>
                                        <label htmlFor="description">Description</label>
                                    </div>

                                    <p className="mb-1">Thumbnail</p>
                                    {
                                        newThumbnail
                                            ? <img className="preview mb-3" src={URL.createObjectURL(newThumbnail)} alt="new" />
                                            : product.thumbnail && <img className="preview mb-3" src={`http://localhost:4000/uploads/${product.thumbnail}`} alt="current" />
                                    }
                                    <div className="mb-3">
                                        <input
                                            type="file"
                                            className="form-control"
                                            accept="image/*"
                                            onChange={(e) => setNewThumbnail(e.target.files[0])}
                                        />
                                        <div className="form-text">Leave empty to keep the current image.</div>
                                    </div>

                                    <div>
                                        <button type="submit" className="btn btn-primary me-2">Save Changes</button>
                                        <button type="button" className="btn btn-secondary" onClick={() => navigate('/')}>Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default EditProduct
