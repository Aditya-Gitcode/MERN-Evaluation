import axios from 'axios'
import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import { NavLink } from 'react-router-dom'

const Home = () => {

    const [products, setProducts] = useState([])
    const [search, setSearch] = useState('')

    useEffect(() => {
        axios.get('http://localhost:4000/product')
            .then((res) => setProducts(res.data))
            .catch((err) => console.log(err))
    }, [])

    const handleDelete = (id) => {
        if (window.confirm('Are you sure you want to delete this product?')) {
            axios.delete(`http://localhost:4000/product/${id}`)
                .then(() => setProducts(products.filter((p) => p._id !== id)))
                .catch((err) => console.log(err))
        }
    }

    // Search by product name, brand or category
    const filteredProducts = products.filter((p) =>
        p.productName.toLowerCase().includes(search.toLowerCase()) ||
        p.brand.toLowerCase().includes(search.toLowerCase()) ||
        p.category.toLowerCase().includes(search.toLowerCase())
    )

    return (
        <>
            <div className="container">
                <div className="card">
                    <div className="card-body">

                        <div className="row mb-3">
                            <div className="col-md-6">
                                <h4 className="card-title">Product List ({filteredProducts.length})</h4>
                            </div>
                            <div className="col-md-6">
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Search by name, brand or category..."
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                />
                            </div>
                        </div>

                        <div className="table-responsive">
                            <table className="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>Thumbnail</th>
                                        <th>Product Name</th>
                                        <th>Brand</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        filteredProducts.map((product) => (
                                            <tr key={product._id}>
                                                <td>
                                                    {
                                                        product.thumbnail
                                                            ? <img className="thumb" src={`http://localhost:4000/uploads/${product.thumbnail}`} alt={product.productName} />
                                                            : <span className="text-muted">No image</span>
                                                    }
                                                </td>
                                                <td>{product.productName}</td>
                                                <td>{product.brand}</td>
                                                <td><span className="badge bg-primary">{product.category}</span></td>
                                                <td>₹{product.price}</td>
                                                <td>
                                                    {
                                                        product.stock > 0
                                                            ? <span className="badge bg-success">{product.stock}</span>
                                                            : <span className="badge bg-danger">Out of stock</span>
                                                    }
                                                </td>
                                                <td>
                                                    <NavLink
                                                        className="btn btn-warning btn-sm me-2"
                                                        to={`/edit/${product._id}`}
                                                        role="button"
                                                    >Edit</NavLink>
                                                    <button
                                                        type="button"
                                                        className="btn btn-danger btn-sm"
                                                        onClick={() => handleDelete(product._id)}
                                                    >
                                                        Delete
                                                    </button>
                                                </td>
                                            </tr>
                                        ))
                                    }
                                </tbody>
                            </table>
                        </div>

                        {
                            filteredProducts.length === 0 &&
                            <p className="text-center text-muted my-4">No products found.</p>
                        }

                    </div>
                </div>
            </div>
        </>
    )
}

export default Home
