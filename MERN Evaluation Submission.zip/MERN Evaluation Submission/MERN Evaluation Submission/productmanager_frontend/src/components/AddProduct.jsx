import React from 'react'
import { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const AddProduct = () => {

    const [product, setProduct] = useState({ productName: '', brand: '', category: '', price: '', stock: '', description: '' })
    const [thumbnail, setThumbnail] = useState(null)
    const navigate = useNavigate()

    const handleSubmit = (e) => {
        e.preventDefault()

        const formData = new FormData()
        formData.append('productName', product.productName)
        formData.append('brand', product.brand)
        formData.append('category', product.category)
        formData.append('price', product.price)
        formData.append('stock', product.stock)
        formData.append('description', product.description)
        formData.append('thumbnail', thumbnail)

        axios.post('http://localhost:4000/product/add', formData)
            .then(() => navigate('/'))
            .catch((err) => console.log(err))
    }

    return (
        <>
            <div className="container">
                <div className="row justify-content-center">
                    <div className="col-md-8">
                        <div className="card">
                            <div className="card-body">
                                <h4 className="card-title mb-3">Add Product</h4>
                                <form onSubmit={handleSubmit}>
                                    <div className="form-floating mb-3">
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="productName"
                                            placeholder=""
                                            required
                                            onChange={(e) => setProduct({ ...product, productName: e.target.value })}
                                        />
                                        <label htmlFor="productName">Product Name</label>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="brand"
                                            placeholder=""
                                            required
                                            onChange={(e) => setProduct({ ...product, brand: e.target.value })}
                                        />
                                        <label htmlFor="brand">Brand</label>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="category"
                                            placeholder=""
                                            required
                                            onChange={(e) => setProduct({ ...product, category: e.target.value })}
                                        />
                                        <label htmlFor="category">Category</label>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-6">
                                            <div className="form-floating mb-3">
                                                <input
                                                    type="number"
                                                    className="form-control"
                                                    id="price"
                                                    placeholder=""
                                                    min="0"
                                                    required
                                                    onChange={(e) => setProduct({ ...product, price: e.target.value })}
                                                />
                                                <label htmlFor="price">Price</label>
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="form-floating mb-3">
                                                <input
                                                    type="number"
                                                    className="form-control"
                                                    id="stock"
                                                    placeholder=""
                                                    min="0"
                                                    required
                                                    onChange={(e) => setProduct({ ...product, stock: e.target.value })}
                                                />
                                                <label htmlFor="stock">Stock</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-floating mb-3">
                                        <textarea
                                            className="form-control"
                                            id="description"
                                            placeholder=""
                                            style={{ height: '100px' }}
                                            onChange={(e) => setProduct({ ...product, description: e.target.value })}
                                        ></textarea>
                                        <label htmlFor="description">Description</label>
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="thumbnail" className="form-label">Product Thumbnail</label>
                                        <input
                                            type="file"
                                            className="form-control"
                                            id="thumbnail"
                                            accept="image/*"
                                            onChange={(e) => setThumbnail(e.target.files[0])}
                                        />
                                    </div>
                                    {
                                        thumbnail &&
                                        <img className="preview mb-3" src={URL.createObjectURL(thumbnail)} alt="preview" />
                                    }
                                    <div>
                                        <button type="submit" className="btn btn-primary me-2">Add Product</button>
                                        <button type="button" className="btn btn-secondary" onClick={() => navigate('/')}>Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default AddProduct
