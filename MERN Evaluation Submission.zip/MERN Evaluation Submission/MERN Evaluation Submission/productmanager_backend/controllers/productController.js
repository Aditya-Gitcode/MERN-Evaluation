const productModel = require('../models/productModel');

exports.addProduct = async (req, res) => {
    const new_product = new productModel(req.body)
    if (req.file) {
        new_product.thumbnail = req.file.filename
    }
    const result = await new_product.save()
    res.status(200).json(result)
}

exports.showProducts = async (req, res) => {
    const products = await productModel.find()
    res.status(200).json(products)
}

exports.showProduct = async (req, res) => {
    const product = await productModel.findById(req.params.id)
    if (product != null) {
        res.status(200).json(product)
    } else {
        res.status(404).json({ message: 'no record found' })
    }
}

exports.updateProduct = async (req, res) => {
    const data = req.body
    if (req.file) {
        data.thumbnail = req.file.filename   
    }
    await productModel.findByIdAndUpdate(req.params.id, data)
    res.status(200).json({ message: 'product updated successfully...' })
}

exports.delProduct = async (req, res) => {
    const product = await productModel.findByIdAndDelete(req.params.id)
    if (product != null) {
        res.status(200).json({ message: 'Product deleted successfully...' })
    } else {
        res.status(404).json({ message: 'Product not found...' })
    }
}
