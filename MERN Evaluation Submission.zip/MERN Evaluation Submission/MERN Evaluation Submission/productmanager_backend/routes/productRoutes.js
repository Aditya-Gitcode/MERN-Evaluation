const express = require('express');
const { addProduct, showProducts, showProduct, updateProduct, delProduct } = require('../controllers/productController');
const upload = require('../middleware/upload');

const routes = express.Router()

routes.post('/add', upload.single('thumbnail'), addProduct)
routes.get('/', showProducts)
routes.put('/:id', upload.single('thumbnail'), updateProduct)
routes.get('/product/:id', showProduct)
routes.delete('/:id', delProduct)

module.exports = routes
