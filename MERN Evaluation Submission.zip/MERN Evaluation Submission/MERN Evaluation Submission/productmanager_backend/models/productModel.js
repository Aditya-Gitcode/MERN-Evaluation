const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    productName: {
        type:String,
        required:true
    },
    brand: {
        type:String,
        required:true
    },
    category:{
        type:String,
        required:true
    },
    price: {
        type:Number,
        min:0,
        required:true
    },
    stock: {
        type:Number,
        min:0,
        required:true
    },
    description: {
        type:String,
        required:true
    },
    thumbnail: {
        type:String,
        required:true
    },
}, {
    timestamps: true
})

const productModel = mongoose.model('products', productSchema)

module.exports = productModel
